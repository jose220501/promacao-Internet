let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoFerraduras(){
    let num1 = Number(inputNumber1.value);

    resultado.innerHTML = (num1 * 4) + "<p>ferraduras necessárias</p>";
}

btCalcular.onclick = function (){
    calculoFerraduras();
}
