let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoReajuste(){
    let salarioInicial = Number(inputNumber1.value);
    let reajuste15 = (salarioInicial * 15) / 100 + salarioInicial;  
    let reajuste8 = (reajuste15 * 8) / 100 + salarioInicial;
    let salarioFinal = (reajuste15 - reajuste8) + salarioInicial;
    
    resultado.innerHTML = "Salário inicial: " + salarioInicial + "<hr>" +
                          "Salário com aumento de 15%: " + reajuste15 + "<hr>" +
                          "Salário final: " + salarioFinal + "<hr>";

}

btCalcular.onclick = function (){
    calculoReajuste();
}
