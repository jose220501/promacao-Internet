let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoAreaPizza(){
    let raio = Number(inputNumber1.value);
    let raioAoQuadrado = (raio ** 2);
    let pi = (3.14)
    let result = (raioAoQuadrado * pi)

    resultado.innerHTML = "Área da pizza: " + result;
}

btCalcular.onclick = function (){
    calculoAreaPizza();
}