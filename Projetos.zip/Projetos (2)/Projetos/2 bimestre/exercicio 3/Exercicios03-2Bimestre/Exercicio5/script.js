let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoGasolina(){
    let num1 = Number(inputNumber1.value);
    let num2 = Number(inputNumber2.value);
    let result = (num2 / num1);
    
    resultado.innerHTML = "Com " + num2 +  " reais você coloca " + (result) + " litros de gasolina no seu tanque.";
}

btCalcular.onclick = function (){
    calculoGasolina();
}
