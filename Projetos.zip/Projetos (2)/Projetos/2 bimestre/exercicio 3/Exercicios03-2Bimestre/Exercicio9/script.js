let inputNumber1 = document.querySelector("#inputNumber1"); 
let inputNumber2 = document.querySelector("#inputNumber2"); 
let inputNumber3 = document.querySelector("#inputNumber3"); 
let inputNumber4 = document.querySelector("#inputNumber4"); 
let btCalcular = document.querySelector("#btCalcular"); 
let resultado = document.querySelector("#resultado"); 

function calculoDistancia(){ 
    let num1 = Number(inputNumber1.value); 
    let num2 = Number(inputNumber2.value); 
    let num3 = Number(inputNumber3.value); 
    let num4 = Number(inputNumber4.value); 
    let subtrairX = (num3 - num1) 
    let subtrairY = (num4 - num2)
    let elevarX = (subtrairX ** 2);
    let elevarY = (subtrairY ** 2);
    let somaResultados = (elevarX + elevarY);
    let raizQuadrada = (Math.sqrt(somaResultados));
    let result = (raizQuadrada);

    resultado.innerHTML = ("A distancia é de " + result + " unidades" ); 
} 

btCalcular.onclick = function (){ 
    calculoDistancia(); 
}