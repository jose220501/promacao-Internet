let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoConversao(){
    let num1 = Number(inputNumber1.value)
    let anos = Math.floor(num1 / 365);
    let diasRestantes = num1 % 365;

    let meses = Math.floor(diasRestantes / 30);

    let dias = (diasRestantes % 30);

    resultado.innerHTML = 
    "Sem acidentes por: " +
    dias + " Dias " + " / " +
    meses + " Meses" + " / " +
    anos + " Anos";
}

btCalcular.onclick = function (){
    calculoConversao();
}
