let Num1 =document.querySelector("#Num1");
let Num2 = document.querySelector("#Num2");
let btSomar = document.querySelector("#btSomar");
let h3Resultado = document.querySelector("#h3Resultado");

function somarNumeros(){
    let num1 = Number(Num1.value);
    let num2 = Number(Num2.value);

    h3Resultado.textContent = (num1 + num2);
}

btSomar.onclick = function(){
 somarNumeros();
}

