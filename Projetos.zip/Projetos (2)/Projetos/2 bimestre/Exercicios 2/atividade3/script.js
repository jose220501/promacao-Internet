// script.js

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('calcForm');
  const num1Input = document.getElementById('num1');
  const num2Input = document.getElementById('num2');
  const num1Error = document.getElementById('num1Error');
  const num2Error = document.getElementById('num2Error');
  const resultsSection = document.getElementById('results');

  // Clear error messages
  function clearErrors() {
    num1Error.textContent = '';
    num2Error.textContent = '';
  }

  // Validate inputs are integers
  function validateInput(value) {
    if (value.trim() === '') {
      return { valid: false, message: 'Este campo é obrigatório.' };
    }
    if (!/^[-+]?\d+$/.test(value)) {
      return { valid: false, message: 'Por favor, insira um número inteiro válido.' };
    }
    return { valid: true };
  }

  // Calculate and display results
  function calculateAndDisplay(n1, n2) {
    const num1 = parseInt(n1, 10);
    const num2 = parseInt(n2, 10);

    let divisionResult = '';
    if (num2 === 0) {
      divisionResult = 'Divisão: Não pode dividir por zero.';
    } else {
      divisionResult = `Divisão: ${num1} ÷ ${num2} = ${(num1 / num2).toFixed(4)}`;
    }

    // Build results string with one operation per line
    const resultsText = [
      `Soma: ${num1} + ${num2} = ${num1 + num2}`,
      `Subtração: ${num1} - ${num2} = ${num1 - num2}`,
      `Multiplicação: ${num1} × ${num2} = ${num1 * num2}`,
      divisionResult
    ].join('\n');

    // Display results with line breaks
    resultsSection.textContent = ''; // Clear previous results
    resultsSection.textContent = resultsText;

    // Focus results for accessibility
    resultsSection.focus();
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    clearErrors();
    resultsSection.textContent = '';

    const val1 = num1Input.value;
    const val2 = num2Input.value;

    const val1Check = validateInput(val1);
    const val2Check = validateInput(val2);

    let hasError = false;

    if (!val1Check.valid) {
      num1Error.textContent = val1Check.message;
      hasError = true;
    }

    if (!val2Check.valid) {
      num2Error.textContent = val2Check.message;
      hasError = true;
    }

    if (hasError) {
      return;
    }

    calculateAndDisplay(val1, val2);
  });
});

