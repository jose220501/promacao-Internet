let saldo = document.querySelector("#saldo")
let reajuste = document.querySelector("#reajuste")
let saldoreajustado = document.querySelector("#saldoreajustado");

function trocarNumero(){
    let saldo0 = Number (saldo.value);
    resultado.textContent = (*);
}

btSomar.onclick = function(){
 trocarNumero();
}