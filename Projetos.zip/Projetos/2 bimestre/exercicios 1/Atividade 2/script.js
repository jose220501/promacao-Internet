let valorquilo = document.querySelector ("#valorquilo");
let quantidade  = document.querySelector ("#quantidade");
let btSomar = document.querySelector ("#btSomar");
let resultado = document.querySelector("#resultado");

function trocarNumero(){
    let quilovalor = Number (valorquilo.value);
    let quantidadevalor = Number (quantidade.value);
    resultado.textContent = (quilovalor*quantidadevalor);
}

btSomar.onclick = function(){
 trocarNumero();
}