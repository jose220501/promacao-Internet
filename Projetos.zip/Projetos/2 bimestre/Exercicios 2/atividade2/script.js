let quatpessoa = document.querySelector("#quatpessoa");
let BtCalcular = document.querySelector("#BtCalcular");
let h3ResultadoOvos = document.querySelector("#h3ResultadoOvos");
let h3ResuldadoQueijo = document.querySelector("#h3ResuldadoQueijo");

function CalcularPessoa (){
    let num1 = Number(quatpessoa.value);

    h3ResultadoOvos.textContent = num1*2;

    h3ResuldadoQueijo.textContent = num1*50;
}

    BtCalcular.onclick  = function(){
        CalcularPessoa()
    }